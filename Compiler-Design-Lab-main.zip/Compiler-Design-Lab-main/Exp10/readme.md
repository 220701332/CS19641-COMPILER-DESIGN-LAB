# See exp10.c
# input.txt
