# see exp12.c
