# See exp9a.c
